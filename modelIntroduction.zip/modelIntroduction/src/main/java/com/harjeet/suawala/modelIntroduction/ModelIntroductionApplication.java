package com.harjeet.suawala.modelIntroduction;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ModelIntroductionApplication {

	public static void main(String[] args) {
		SpringApplication.run(ModelIntroductionApplication.class, args);
	}

}
